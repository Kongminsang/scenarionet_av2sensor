#!/usr/bin/env bash

bash ../../convert_pg_large.sh ../tmp/pg_large 4 64 8 true